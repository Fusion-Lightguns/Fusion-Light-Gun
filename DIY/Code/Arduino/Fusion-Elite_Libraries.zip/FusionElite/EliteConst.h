/*!
 * @file EliteConst.h
 * @brief Global constants for the Elite light gun.
 *
 * @copyright Mike Lynch, 2021
 * @copyright GNU Lesser General Public License
 *
 * @author Mike Lynch
 * @author Gonezo Fusion Lightguns
 * @version V1.1
 * @date 2023
 */

#ifndef _ELITECONST_H_
#define _ELITECONST_H_

// DFRobot IR positioning camera resolution
constexpr int CamResX = 1024;
constexpr int CamResY = 768;

// DFRobot IR positioning camera maximum X and Y
constexpr int CamMaxX = CamResX - 1;
constexpr int CamMaxY = CamResY - 1;

// shift amount for extra precision for the maths
// since the median is an average of 4 values, use 2 more bits
constexpr int CamToMouseShift = 2;

// multiplier to convert IR camera position to mouse position
constexpr int CamToMouseMult = 1 << CamToMouseShift;

// mouse resolution
constexpr int MouseResX = CamResX * CamToMouseMult;
constexpr int MouseResY = CamResY * CamToMouseMult;

// Mouse position maximum X and Y
constexpr int MouseMaxX = MouseResX - 1;
constexpr int MouseMaxY = MouseResY - 1;

#endif // _ELITECONST_H_
